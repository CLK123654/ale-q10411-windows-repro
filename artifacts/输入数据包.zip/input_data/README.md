账号接管调查组提供了一份脱敏设备图谱。database/risk_graph.db保存账号、设备、关系边和高风险种子事件；rules/graph_policy.json规定关系准入、传播和动作档位；rules/action_routes.csv记录处置动作的责任团队、案件优先级与复核时限。

请把完成版SQL保存到output/sql/rebuild_device_review.sql，再在input_data目录运行npm run rebuild。入口会复制源库，把规则装入同一SQLite连接，执行交付SQL并导出三份报告。运行期间只读取本目录，不连接外部系统。
