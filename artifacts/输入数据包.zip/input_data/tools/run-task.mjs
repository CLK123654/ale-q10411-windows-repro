import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import { spawnSync } from 'node:child_process';

const root = process.cwd();
const inputDb = path.join(root, 'database', 'risk_graph.db');
const policyPath = path.join(root, 'rules', 'graph_policy.json');
const routePath = path.join(root, 'rules', 'action_routes.csv');
const outputRoot = path.join(root, 'output');
const outputDb = path.join(outputRoot, 'device_risk_review.db');
const candidateSql = path.join(outputRoot, 'sql', 'rebuild_device_review.sql');
const reportsRoot = path.join(outputRoot, 'reports');
const sqliteCommand = process.env.SQLITE3_PATH || (process.platform === 'win32' ? 'sqlite3.exe' : 'sqlite3');

function sqlText(value) {
  return `'${String(value).replaceAll("'", "''")}'`;
}

async function requireFile(file) {
  await fs.access(file);
}

function runSqlite(args, input) {
  const result = spawnSync(sqliteCommand, args, {
    cwd: root,
    input,
    encoding: 'utf8',
    timeout: 30000,
    windowsHide: true
  });
  if (result.error) throw result.error;
  if (result.status !== 0) {
    throw new Error(`SQLite执行失败，退出码${result.status ?? 'signal'}\n${result.stdout}\n${result.stderr}`);
  }
  return result.stdout;
}

function buildPolicySql(policy) {
  const scalar = {
    policy_version: policy.policy_version,
    report_as_of_utc: policy.report_as_of_utc,
    min_confidence: policy.min_confidence,
    max_depth: policy.max_depth,
    propagation_decay: policy.propagation_decay,
    eligible_account_status: policy.eligible_account_status,
    eligible_device_status: policy.eligible_device_status,
    path_confidence_round_digits: policy.path_confidence_round_digits,
    risk_score_round_digits: policy.risk_score_round_digits,
    queue_threshold: policy.queue_threshold
  };
  return [
    'PRAGMA foreign_keys=ON;',
    'CREATE TEMP TABLE task_policy(key TEXT PRIMARY KEY,value TEXT NOT NULL);',
    ...Object.entries(scalar).map(([key, value]) => `INSERT INTO task_policy VALUES(${sqlText(key)},${sqlText(value)});`),
    'CREATE TEMP TABLE task_allowed_link_type(link_type TEXT PRIMARY KEY);',
    ...policy.allowed_link_types.map((value) => `INSERT INTO task_allowed_link_type VALUES(${sqlText(value)});`),
    'CREATE TEMP TABLE task_reason_order(priority INTEGER PRIMARY KEY,reason TEXT UNIQUE NOT NULL);',
    ...policy.rejection_reason_order.map((value, index) => `INSERT INTO task_reason_order VALUES(${index + 1},${sqlText(value)});`),
    'CREATE TEMP TABLE task_queue_action(min_score REAL PRIMARY KEY,action TEXT UNIQUE NOT NULL);',
    ...policy.queue_actions.map((item) => `INSERT INTO task_queue_action VALUES(${Number(item.min_score)},${sqlText(item.action)});`),
    'DROP TABLE IF EXISTS action_route;',
    'CREATE TABLE action_route(action TEXT PRIMARY KEY,owner_team TEXT NOT NULL,case_priority TEXT NOT NULL,review_sla_minutes INTEGER NOT NULL CHECK(review_sla_minutes>0));',
    '.mode csv',
    `.import --skip 1 "${routePath.replaceAll('\\', '/').replaceAll('"', '""')}" action_route`
  ].join('\n');
}

async function clearGenerated() {
  await fs.rm(outputDb, { force: true });
  await fs.rm(reportsRoot, { recursive: true, force: true });
}

async function exportCsv(name, query) {
  const csv = runSqlite(['-header', '-csv', outputDb, query]);
  await fs.writeFile(path.join(reportsRoot, name), csv, 'utf8');
}

try {
  await Promise.all([inputDb, policyPath, routePath, candidateSql].map(requireFile));
  const versionText = runSqlite(['--version']).trim();
  const version = versionText.split(/\s+/)[0].split('.').map(Number);
  if (version[0] < 3 || version[0] === 3 && version[1] < 40) {
    throw new Error(`SQLite版本过低：${versionText}`);
  }

  const policy = JSON.parse(await fs.readFile(policyPath, 'utf8'));
  const routeLines = (await fs.readFile(routePath, 'utf8')).trim().split(/\r?\n/).slice(1);
  const routeActions = new Set(routeLines.map((line) => line.split(',')[0]));
  const missingRouteActions = policy.queue_actions.map((item) => item.action).filter((action) => !routeActions.has(action));
  if (missingRouteActions.length) {
    throw new Error(`动作路由缺失：${missingRouteActions.join(',')}`);
  }
  const sql = await fs.readFile(candidateSql, 'utf8');
  await clearGenerated();
  await fs.mkdir(reportsRoot, { recursive: true });
  await fs.copyFile(inputDb, outputDb);
  runSqlite([outputDb], `${buildPolicySql(policy)}\n${sql}\n`);

  await exportCsv('risk_paths.csv', 'SELECT seed_incident_id,account_id,device_id,depth,path_confidence,risk_score,evidence_path FROM account_risk ORDER BY risk_score DESC,account_id,device_id;');
  await exportCsv('action_queue.csv', 'SELECT queue_rank,seed_incident_id,account_id,device_id,action,owner_team,case_priority,review_sla_minutes,due_at_utc,risk_score,evidence_path FROM action_queue ORDER BY queue_rank;');
  await exportCsv('rejected_links.csv', 'SELECT edge_id,left_device_id,right_device_id,reason,detail FROM rejected_link ORDER BY edge_id;');

  const integrity = runSqlite([outputDb, 'PRAGMA integrity_check;']).trim();
  if (integrity !== 'ok') throw new Error(`数据库完整性检查失败：${integrity}`);
  console.log('设备路径与处置队列已生成');
} catch (error) {
  await clearGenerated();
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 2;
}
