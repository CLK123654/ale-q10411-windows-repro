PRAGMA foreign_keys=ON;
BEGIN IMMEDIATE;

DROP TABLE IF EXISTS action_queue;
DROP TABLE IF EXISTS account_risk;
DROP TABLE IF EXISTS device_path;
DROP TABLE IF EXISTS active_seed;
DROP TABLE IF EXISTS eligible_edge;
DROP TABLE IF EXISTS rejected_link;

CREATE TABLE rejected_link AS
WITH endpoint AS (
  SELECT e.edge_id,e.left_device_id,e.right_device_id,e.link_type,e.confidence,
         dl.device_status AS left_device_status,dr.device_status AS right_device_status,
         al.account_status AS left_account_status,ar.account_status AS right_account_status
  FROM device_link_event e
  JOIN device_registry dl ON dl.device_id=e.left_device_id
  JOIN device_registry dr ON dr.device_id=e.right_device_id
  JOIN account_profile al ON al.account_id=dl.owner_account_id
  JOIN account_profile ar ON ar.account_id=dr.owner_account_id
), candidate AS (
  SELECT edge_id,left_device_id,right_device_id,'low_confidence' AS reason,
         'confidence='||printf('%.2f',confidence) AS detail
  FROM endpoint
  WHERE confidence<CAST((SELECT value FROM task_policy WHERE key='min_confidence') AS REAL)
  UNION ALL
  SELECT edge_id,left_device_id,right_device_id,'link_type_not_allowed','link_type='||link_type
  FROM endpoint
  WHERE link_type NOT IN(SELECT link_type FROM task_allowed_link_type)
  UNION ALL
  SELECT edge_id,left_device_id,right_device_id,'endpoint_device_inactive',left_device_status||'/'||right_device_status
  FROM endpoint
  WHERE left_device_status<>(SELECT value FROM task_policy WHERE key='eligible_device_status')
     OR right_device_status<>(SELECT value FROM task_policy WHERE key='eligible_device_status')
  UNION ALL
  SELECT edge_id,left_device_id,right_device_id,'endpoint_account_disabled',left_account_status||'/'||right_account_status
  FROM endpoint
  WHERE left_account_status<>(SELECT value FROM task_policy WHERE key='eligible_account_status')
     OR right_account_status<>(SELECT value FROM task_policy WHERE key='eligible_account_status')
), ranked AS (
  SELECT c.*,ROW_NUMBER() OVER(PARTITION BY c.edge_id ORDER BY r.priority) AS reason_rank
  FROM candidate c
  JOIN task_reason_order r ON r.reason=c.reason
)
SELECT edge_id,left_device_id,right_device_id,reason,detail
FROM ranked
WHERE reason_rank=1;

CREATE TABLE eligible_edge AS
SELECT e.edge_id,e.left_device_id AS from_device_id,e.right_device_id AS to_device_id,e.link_type,e.confidence
FROM device_link_event e
WHERE NOT EXISTS(SELECT 1 FROM rejected_link r WHERE r.edge_id=e.edge_id)
UNION ALL
SELECT e.edge_id,e.right_device_id,e.left_device_id,e.link_type,e.confidence
FROM device_link_event e
WHERE NOT EXISTS(SELECT 1 FROM rejected_link r WHERE r.edge_id=e.edge_id);

CREATE TABLE active_seed AS
SELECT s.*
FROM seed_incident s
JOIN account_profile a ON a.account_id=s.account_id
JOIN device_registry d ON d.device_id=s.device_id AND d.owner_account_id=s.account_id
WHERE a.account_status=(SELECT value FROM task_policy WHERE key='eligible_account_status')
  AND d.device_status=(SELECT value FROM task_policy WHERE key='eligible_device_status');

CREATE TABLE device_path AS
WITH RECURSIVE path_candidate(seed_incident_id,seed_device_id,device_id,depth,evidence_path,path_confidence,risk_score) AS (
  SELECT incident_id,device_id,device_id,0,device_id,1.0,seed_weight
  FROM active_seed
  UNION ALL
  SELECT p.seed_incident_id,p.seed_device_id,e.to_device_id,p.depth+1,
         p.evidence_path||'>'||e.to_device_id,
         p.path_confidence*e.confidence,
         p.risk_score*e.confidence*CAST((SELECT value FROM task_policy WHERE key='propagation_decay') AS REAL)
  FROM path_candidate p
  JOIN eligible_edge e ON e.from_device_id=p.device_id
  WHERE p.depth<CAST((SELECT value FROM task_policy WHERE key='max_depth') AS INTEGER)
    AND instr('>'||p.evidence_path||'>','>'||e.to_device_id||'>')=0
), preferred AS (
  SELECT *,ROW_NUMBER() OVER(
    PARTITION BY seed_incident_id,device_id
    ORDER BY risk_score DESC,depth ASC,evidence_path ASC
  ) AS path_rank
  FROM path_candidate
)
SELECT seed_incident_id,seed_device_id,device_id,depth,evidence_path,path_confidence,risk_score
FROM preferred
WHERE path_rank=1;

CREATE TABLE account_risk AS
SELECT p.seed_incident_id,d.owner_account_id AS account_id,p.device_id,p.depth,
       ROUND(p.path_confidence,CAST((SELECT value FROM task_policy WHERE key='path_confidence_round_digits') AS INTEGER)) AS path_confidence,
       ROUND(p.risk_score,CAST((SELECT value FROM task_policy WHERE key='risk_score_round_digits') AS INTEGER)) AS risk_score,
       p.evidence_path
FROM device_path p
JOIN device_registry d ON d.device_id=p.device_id;

CREATE TABLE action_queue AS
WITH selected_action AS (
  SELECT r.*,
         (SELECT q.action FROM task_queue_action q WHERE r.risk_score>=q.min_score ORDER BY q.min_score DESC LIMIT 1) AS action
  FROM account_risk r
  WHERE r.risk_score>=CAST((SELECT value FROM task_policy WHERE key='queue_threshold') AS REAL)
), routed AS (
  SELECT s.*,a.owner_team,a.case_priority,a.review_sla_minutes,
         strftime('%Y-%m-%dT%H:%M:%SZ',datetime(i.detected_at_utc,'+'||a.review_sla_minutes||' minutes')) AS due_at_utc
  FROM selected_action s
  JOIN action_route a ON a.action=s.action
  JOIN active_seed i ON i.incident_id=s.seed_incident_id
)
SELECT ROW_NUMBER() OVER(ORDER BY risk_score DESC,account_id,device_id) AS queue_rank,
       seed_incident_id,account_id,device_id,action,owner_team,case_priority,
       review_sla_minutes,due_at_utc,risk_score,evidence_path
FROM routed;

COMMIT;
